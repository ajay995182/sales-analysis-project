"""
Run this script once to generate sample_data.xlsx inside the data/ folder.
Usage: python generate_sample_data.py
"""
import pandas as pd
import numpy as np
import os

np.random.seed(42)
n = 300

categories   = ["Technology", "Furniture", "Office Supplies"]
sub_cats     = {"Technology": ["Phones", "Laptops", "Accessories"],
                "Furniture":  ["Chairs", "Tables", "Bookcases"],
                "Office Supplies": ["Paper", "Binders", "Pens"]}
regions      = ["East", "West", "Central", "South"]
segments     = ["Consumer", "Corporate", "Home Office"]
customers    = [f"Customer_{i}" for i in range(1, 51)]

cat_choices  = np.random.choice(categories, n)
sub_choices  = [np.random.choice(sub_cats[c]) for c in cat_choices]
sales        = np.round(np.random.uniform(50, 2000, n), 2)
discount     = np.round(np.random.uniform(0, 0.4, n), 2)
profit       = np.round(sales * np.random.uniform(0.05, 0.35, n) * (1 - discount), 2)
order_dates  = pd.date_range("2022-01-01", "2023-12-31", periods=n)

df = pd.DataFrame({
    "Order ID":       [f"ORD-{1000+i}" for i in range(n)],
    "Order Date":     order_dates,
    "Customer Name":  np.random.choice(customers, n),
    "Segment":        np.random.choice(segments, n),
    "Region":         np.random.choice(regions, n),
    "Category":       cat_choices,
    "Sub-Category":   sub_choices,
    "Sales":          sales,
    "Discount":       discount,
    "Profit":         profit,
    "Quantity":       np.random.randint(1, 10, n),
})

# Inject a few nulls and duplicates so cleaning is visible
df.loc[np.random.choice(n, 10, replace=False), "Sales"]  = np.nan
df.loc[np.random.choice(n, 10, replace=False), "Profit"] = np.nan
df = pd.concat([df, df.iloc[:5]], ignore_index=True)   # 5 duplicate rows

os.makedirs("data", exist_ok=True)
df.to_excel("data/sample_data.xlsx", index=False)
print(f"✅  sample_data.xlsx created  ({len(df)} rows, {df.columns.tolist()})")
