"""
eda.py – Step 3: Feature engineering + exploratory data analysis.
"""
import pandas as pd

def feature_engineering(df: pd.DataFrame) -> pd.DataFrame:
    if "Order Date" in df.columns:
        df["Month"]      = df["Order Date"].dt.month
        df["Year"]       = df["Order Date"].dt.year
        df["Month-Year"] = df["Order Date"].dt.to_period("M").astype(str)
        print("  ✔ Added Month / Year / Month-Year features")

    if {"Sales", "Profit"}.issubset(df.columns):
        df["Profit Margin %"] = (df["Profit"] / df["Sales"].replace(0, pd.NA) * 100).round(2)
        print("  ✔ Added 'Profit Margin %' feature")

    return df

def perform_eda(df: pd.DataFrame) -> None:
    print("\n  📋 Shape          :", df.shape)
    print("  📋 Columns        :", df.columns.tolist())
    print("  📋 Dtypes\n", df.dtypes.to_string())
    print("\n  📋 Describe\n", df.describe(include="all").to_string())

    if "Category" in df.columns and "Sales" in df.columns:
        print("\n  📋 Sales by Category\n",
              df.groupby("Category")["Sales"].sum().sort_values(ascending=False).to_string())

    if "Region" in df.columns and "Sales" in df.columns:
        print("\n  📋 Sales by Region\n",
              df.groupby("Region")["Sales"].sum().sort_values(ascending=False).to_string())
