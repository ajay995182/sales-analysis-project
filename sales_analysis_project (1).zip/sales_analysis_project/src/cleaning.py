"""
cleaning.py – Step 2: Clean the raw dataframe.
"""
import pandas as pd

def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    before = len(df)

    # Drop full duplicates
    df = df.drop_duplicates()
    print(f"  ✔ Removed {before - len(df)} duplicate rows")

    # Fill missing numeric values with column median
    num_cols = df.select_dtypes(include="number").columns
    null_counts = df[num_cols].isnull().sum()
    df[num_cols] = df[num_cols].fillna(df[num_cols].median())
    filled = null_counts[null_counts > 0]
    if not filled.empty:
        for col, cnt in filled.items():
            print(f"  ✔ Filled {cnt} nulls in '{col}' with median")

    # Parse Order Date if present
    if "Order Date" in df.columns:
        df["Order Date"] = pd.to_datetime(df["Order Date"], errors="coerce")
        print("  ✔ Parsed 'Order Date' to datetime")

    # Strip whitespace from string columns
    str_cols = df.select_dtypes(include="object").columns
    df[str_cols] = df[str_cols].apply(lambda c: c.str.strip())

    print(f"  ✔ Clean dataframe: {len(df):,} rows remaining")
    return df
