"""
dashboard.py – Step 5: Interactive Plotly Dash dashboard.
"""
import pandas as pd
import plotly.express as px
import dash
from dash import dcc, html, Input, Output
import dash_bootstrap_components as dbc

def create_dashboard(df: pd.DataFrame, debug: bool = False) -> None:
    app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
    app.title = "Sales Dashboard"

    categories = sorted(df["Category"].dropna().unique()) if "Category" in df.columns else []
    regions    = sorted(df["Region"].dropna().unique())   if "Region"   in df.columns else []

    app.layout = dbc.Container([
        html.H2("📊 Sales Analysis Dashboard", className="my-3 text-center"),

        dbc.Row([
            dbc.Col([
                html.Label("Filter by Category"),
                dcc.Dropdown(id="cat-filter",
                             options=[{"label": c, "value": c} for c in categories],
                             multi=True, placeholder="All categories"),
            ], md=6),
            dbc.Col([
                html.Label("Filter by Region"),
                dcc.Dropdown(id="reg-filter",
                             options=[{"label": r, "value": r} for r in regions],
                             multi=True, placeholder="All regions"),
            ], md=6),
        ], className="mb-3"),

        dbc.Row([
            dbc.Col(dcc.Graph(id="bar-category"), md=6),
            dbc.Col(dcc.Graph(id="bar-region"),   md=6),
        ]),
        dbc.Row([
            dbc.Col(dcc.Graph(id="trend-chart"),  md=8),
            dbc.Col(dcc.Graph(id="pie-segment"),  md=4),
        ]),
        dbc.Row([
            dbc.Col(dcc.Graph(id="scatter-plot"), md=12),
        ]),
    ], fluid=True)

    @app.callback(
        [Output("bar-category", "figure"),
         Output("bar-region",   "figure"),
         Output("trend-chart",  "figure"),
         Output("pie-segment",  "figure"),
         Output("scatter-plot", "figure")],
        [Input("cat-filter", "value"),
         Input("reg-filter", "value")],
    )
    def update(cats, regs):
        filtered = df.copy()
        if cats and "Category" in filtered.columns:
            filtered = filtered[filtered["Category"].isin(cats)]
        if regs and "Region" in filtered.columns:
            filtered = filtered[filtered["Region"].isin(regs)]

        fig_cat = px.bar(
            filtered.groupby("Category")["Sales"].sum().reset_index() if "Category" in filtered.columns else pd.DataFrame(),
            x="Category", y="Sales", title="Sales by Category", color="Category"
        )
        fig_reg = px.bar(
            filtered.groupby("Region")["Sales"].sum().reset_index() if "Region" in filtered.columns else pd.DataFrame(),
            x="Region", y="Sales", title="Sales by Region", color="Region"
        )
        fig_trend = px.line(
            filtered.groupby("Month-Year")["Sales"].sum().reset_index() if "Month-Year" in filtered.columns else pd.DataFrame(),
            x="Month-Year", y="Sales", title="Monthly Sales Trend", markers=True
        )
        fig_pie = px.pie(
            filtered.groupby("Segment")["Sales"].sum().reset_index() if "Segment" in filtered.columns else pd.DataFrame(),
            names="Segment", values="Sales", title="Sales by Segment"
        )
        fig_scatter = px.scatter(
            filtered if {"Sales","Profit"}.issubset(filtered.columns) else pd.DataFrame(),
            x="Sales", y="Profit",
            color="Category" if "Category" in filtered.columns else None,
            title="Profit vs Sales", opacity=0.7
        )
        return fig_cat, fig_reg, fig_trend, fig_pie, fig_scatter

    print("\n  🌐 Dashboard running at http://127.0.0.1:8050")
    app.run(debug=debug, host="127.0.0.1", port=8050)
