"""
visualization.py – Step 4: Generate and save static PNG charts.
"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

OUTPUT_DIR = "charts"
os.makedirs(OUTPUT_DIR, exist_ok=True)

def _save(fig, name: str) -> None:
    path = os.path.join(OUTPUT_DIR, name)
    fig.savefig(path, bbox_inches="tight", dpi=120)
    plt.close(fig)
    print(f"  💾 Saved {path}")

def generate_all_charts(df: pd.DataFrame) -> None:
    # 1. Sales by Category
    if "Category" in df.columns and "Sales" in df.columns:
        fig, ax = plt.subplots(figsize=(8, 5))
        data = df.groupby("Category")["Sales"].sum().sort_values()
        data.plot(kind="barh", ax=ax, color="steelblue")
        ax.set_title("Total Sales by Category")
        ax.set_xlabel("Sales ($)")
        _save(fig, "sales_by_category.png")

    # 2. Sales by Region
    if "Region" in df.columns and "Sales" in df.columns:
        fig, ax = plt.subplots(figsize=(7, 5))
        data = df.groupby("Region")["Sales"].sum().sort_values(ascending=False)
        sns.barplot(x=data.index, y=data.values, ax=ax, palette="viridis")
        ax.set_title("Total Sales by Region")
        ax.set_ylabel("Sales ($)")
        _save(fig, "sales_by_region.png")

    # 3. Monthly Sales Trend
    if "Month-Year" in df.columns and "Sales" in df.columns:
        fig, ax = plt.subplots(figsize=(12, 5))
        trend = df.groupby("Month-Year")["Sales"].sum().reset_index()
        ax.plot(trend["Month-Year"], trend["Sales"], marker="o", color="darkorange")
        ax.set_title("Monthly Sales Trend")
        ax.set_xlabel("Month")
        ax.set_ylabel("Sales ($)")
        plt.xticks(rotation=45, ha="right")
        _save(fig, "monthly_trend.png")

    # 4. Profit vs Sales Scatter
    if {"Sales", "Profit"}.issubset(df.columns):
        fig, ax = plt.subplots(figsize=(7, 6))
        hue = "Category" if "Category" in df.columns else None
        sns.scatterplot(data=df, x="Sales", y="Profit", hue=hue, alpha=0.6, ax=ax)
        ax.set_title("Profit vs Sales")
        _save(fig, "profit_vs_sales.png")

    # 5. Segment Pie Chart
    if "Segment" in df.columns and "Sales" in df.columns:
        fig, ax = plt.subplots(figsize=(6, 6))
        data = df.groupby("Segment")["Sales"].sum()
        ax.pie(data, labels=data.index, autopct="%1.1f%%", startangle=140)
        ax.set_title("Sales by Segment")
        _save(fig, "sales_by_segment.png")

    print(f"  ✅ All charts saved to ./{OUTPUT_DIR}/")
