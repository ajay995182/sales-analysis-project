"""
loader.py – Step 1: Load data from CSV, Excel, or JSON.
"""
import pandas as pd
import os

def load_data(file_path: str) -> pd.DataFrame:
    ext = os.path.splitext(file_path)[-1].lower()
    loaders = {
        ".csv":  pd.read_csv,
        ".xlsx": pd.read_excel,
        ".json": pd.read_json,
    }
    if ext not in loaders:
        raise ValueError(f"Unsupported file type: {ext}")
    df = loaders[ext](file_path)
    print(f"  ✔ Loaded {len(df):,} rows × {len(df.columns)} columns")
    return df
