# main.py
"""
Sales Data Analysis & Visualization System
==========================================
Usage:
    python main.py                        # prompts for file path
    python main.py data/sample_data.xlsx  # direct path
    python main.py --charts-only          # skip dashboard

Steps
-----
1. Load   → 2. Clean  → 3. Feature Engineering
4. EDA    → 5. Charts → 6. Dashboard
"""

import sys
import os

# Make sure src/ is importable
sys.path.insert(0, os.path.dirname(__file__))

from src.loader        import load_data
from src.cleaning      import clean_data
from src.eda           import feature_engineering, perform_eda
from src.visualization import generate_all_charts
from src.dashboard     import create_dashboard


BANNER = """
╔══════════════════════════════════════════════════════╗
║        📊  Sales Data Analysis System  📊            ║
║        Supports:  .csv  |  .xlsx  |  .json           ║
╚══════════════════════════════════════════════════════╝
"""


def main():
    print(BANNER)

    # ── Resolve file path ────────────────────────────────────────────────────
    charts_only = "--charts-only" in sys.argv
    args = [a for a in sys.argv[1:] if not a.startswith("--")]

    if args:
        file_path = args[0]
    else:
        default = "data/sample_data.xlsx"
        print(f"  Enter the path to your data file")
        print(f"  (Press Enter to use default: {default})")
        user_input = input("  File path: ").strip()
        file_path  = user_input if user_input else default

    if not os.path.exists(file_path):
        print(f"\n❌  File not found: '{file_path}'")
        print("    Tip: run  python generate_sample_data.py  first.")
        sys.exit(1)

    # ── Pipeline ─────────────────────────────────────────────────────────────
    print(f"\n📂  Loading  '{file_path}' …")
    df = load_data(file_path)

    print("\n🧹  Cleaning …")
    df = clean_data(df)

    print("\n⚙️   Feature engineering …")
    df = feature_engineering(df)

    print("\n🔍  Running EDA …")
    perform_eda(df)

    print("\n📊  Generating static charts …")
    generate_all_charts(df)

    if charts_only:
        print("\n✅  Done (--charts-only flag set, skipping dashboard)")
        return

    print("\n🚀  Launching interactive dashboard …")
    create_dashboard(df, debug=False)


if __name__ == "__main__":
    main()
